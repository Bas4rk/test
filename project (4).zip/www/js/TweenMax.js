$('.obj01').on({
        'mouseenter': function(){
            TweenMax.to('#bgc01', 0.25, {width: "100%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid gray",color: "gray"});
            TweenMax.staggerTo('.obj01t', 0.25, {rotationX: 360}, 0.02);
        },
        'mouseleave': function(){
            TweenMax.to('#bgc01', 0.25, {width: "0%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid white",color: "white"});
            TweenMax.staggerTo('.obj01t', 0.25, {rotationX: -360}, 0.02);
        }
});

$('.obj02').on({
        'mouseenter': function(){
            TweenMax.to('#bgc02', 0.25, {width: "100%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05',0.25, {border: "1px solid gray",color: "gray"});
            TweenMax.staggerTo('.obj02t', 0.25, {rotationX: 360}, 0.02);
        },
        'mouseleave': function(){
            TweenMax.to('#bgc02', 0.25, {width: "0%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid white",color: "white"});
            TweenMax.staggerTo('.obj02t', 0.25, {rotationX: -360}, 0.02);
        }
});

$('.obj03').on({
       'mouseenter': function(){
            TweenMax.to('#bgc03', 0.25, {width: "100%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05',0.25, {border: "1px solid gray",color: "gray"});
            TweenMax.staggerTo('.obj03t', 0.25, {rotationX: 360}, 0.02);
        },
        'mouseleave': function(){
            TweenMax.to('#bgc03', 0.25, {width: "0%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid white",color: "white"});
            TweenMax.staggerTo('.obj03t', 0.25, {rotationX: -360}, 0.02);
        }
});

$('.obj04').on({
        'mouseenter': function(){
            TweenMax.to('#bgc04', 0.25, {width: "100%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid gray",color: "gray"});
            TweenMax.staggerTo('.obj04t', 0.25, {rotationX: 360}, 0.02);
        },
        'mouseleave': function(){
            TweenMax.to('#bgc04', 0.25, {width: "0%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid white",color: "white"});
            TweenMax.staggerTo('.obj04t', 0.25, {rotationX: -360}, 0.02);
        }
});

$('.obj05').on({
        'mouseenter': function(){
            TweenMax.to('#bgc05', 0.25, {width: "100%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid gray",color: "gray"});
            TweenMax.staggerTo('.obj05t', 0.25, {rotationX: 360}, 0.02);
        },
        'mouseleave': function(){
            TweenMax.to('#bgc05', 0.25, {width: "0%" });
            TweenMax.to('.obj01,.obj02,.obj03,.obj04,.obj05', 0.25, {border: "1px solid white",color: "white"});
            TweenMax.staggerTo('.obj05t', 0.25, {rotationX: -360}, 0.02);
        }
});